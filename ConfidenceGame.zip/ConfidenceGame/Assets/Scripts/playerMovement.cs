﻿using UnityEngine;
using System.Collections;

public class playerMovement : MonoBehaviour {

	public GameObject runner;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

	}
}
